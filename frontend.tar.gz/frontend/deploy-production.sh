#!/bin/bash

# Production deployment script for Webarmonium Frontend
# Server: tripitak.it (IP: 164.92.147.74)

set -e

echo "🚀 Starting Webarmonium Frontend Production Deployment"

# Configuration
SERVER_IP="164.92.147.74"
SERVER_USER="root"  # Change if needed
REMOTE_DIR="/var/www/webarmonium/frontend"
PORT="3000"
BACKEND_URL="http://164.92.147.74:3001"  # Update if different

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}📋 Deployment Configuration:${NC}"
echo -e "   Server: ${SERVER_IP}"
echo -e "   Remote Directory: ${REMOTE_DIR}"
echo -e "   Port: ${PORT}"
echo -e "   Backend URL: ${BACKEND_URL}"
echo ""

# Check if we're on the production branch
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
if [ "$CURRENT_BRANCH" != "production-frontend" ]; then
    echo -e "${RED}❌ Error: Not on production-frontend branch${NC}"
    echo -e "   Current branch: $CURRENT_BRANCH"
    exit 1
fi

echo -e "${GREEN}✅ Branch check passed: $CURRENT_BRANCH${NC}"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}📦 Installing production dependencies...${NC}"
    npm ci --only=production
else
    echo -e "${GREEN}✅ Dependencies already installed${NC}"
fi

# Run tests
echo -e "${YELLOW}🧪 Running production tests...${NC}"
npm test

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Tests passed${NC}"
else
    echo -e "${RED}❌ Tests failed${NC}"
    exit 1
fi

# Update production configuration
echo -e "${YELLOW}⚙️ Updating production configuration...${NC}"

# Create production config file
cat > config-production.js << EOF
// Production configuration for Webarmonium Frontend
const CONFIG = {
  BACKEND_URL: '$BACKEND_URL',
  ROOM_ID: 'production-room',
  DEBUG: false,
  CANVAS_FPS: 60,
  AUDIO_LATENCY_COMPENSATION: 0.1,
  CURSOR_SMOOTHING: 0.3
};
EOF

# Update main.js to use production config if needed
if grep -q "CONFIG.BACKEND_URL" src/main.js; then
    echo -e "${GREEN}✅ Production configuration already integrated${NC}"
else
    echo -e "${YELLOW}📝 Adding production configuration to main.js...${NC}"
    # Add config import at the top of main.js
    sed -i '1i import "./config-production.js";' src/main.js
fi

# Create production-optimized index.html if needed
echo -e "${YELLOW}🔧 Optimizing for production...${NC}"

# Create deployment package
echo -e "${YELLOW}📦 Creating deployment package...${NC}"
tar -czf webarmonium-frontend-deploy.tar.gz \
    --exclude=node_modules \
    --exclude=.git \
    --exclude=tests \
    --exclude=*.log \
    --exclude=coverage \
    --exclude=deploy-production.sh \
    .

echo -e "${GREEN}✅ Deployment package created${NC}"

# Deploy to server (this would need SSH keys to be set up)
echo -e "${YELLOW}🚀 Deploying to server...${NC}"
echo -e "${YELLOW}   Note: This requires SSH access to be configured${NC}"

exit 0

# Example deployment commands (uncomment when SSH is set up)
# ssh $SERVER_USER@$SERVER_IP "mkdir -p $REMOTE_DIR"
scp webarmonium-frontend-deploy.tar.gz $SERVER_USER@$SERVER_IP:$REMOTE_DIR/
# ssh $SERVER_USER@$SERVER_IP "cd $REMOTE_DIR && tar -xzf webarmonium-frontend-deploy.tar.gz && rm webarmonium-frontend-deploy.tar.gz"
# ssh $SERVER_USER@$SERVER_IP "cd $REMOTE_DIR && npm ci --only=production"
# ssh $SERVER_USER@$SERVER_IP "pm2 restart webarmonium-frontend || pm2 start 'npx http-server . -p 3000 --cors' --name webarmonium-frontend"

echo -e "${GREEN}✅ Frontend deployment script completed${NC}"
echo -e "${YELLOW}📝 Next steps:${NC}"
echo -e "   1. Set up SSH access to $SERVER_IP"
echo -e "   2. Configure PM2 process manager on server"
echo -e "   3. Set up nginx as reverse proxy for port 80/443"
echo -e "   4. Configure SSL certificate (Let's Encrypt recommended)"
echo -e "   5. Uncomment and run the SSH deployment commands"

# Clean up
rm -f webarmonium-frontend-deploy.tar.gz